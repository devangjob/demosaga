import {
    Platform,
    StatusBar,
    Dimensions,
    StyleSheet,
  } from 'react-native';

const style = StyleSheet.create({

    containerStyle : {

        flex : 1,
        justifyContent : "center" ,
        alignItems: 'center'

    }




});

export default style;