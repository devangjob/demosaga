const global = {

apiUrl : 'https://pte.examgroup.org/'



};

export default global;