import { applyMiddleware, createStore, compose } from 'redux';

//import { persistStore } from 'redux-persist';
import createSagaMiddleware from 'redux-saga';
import rootSaga from './Sagas/index';
import getRootReducer from './Reducers/index';
// create the saga applyMiddleware
const sagaMiddleware = createSagaMiddleware();

const composeEnhancers =
  typeof window === 'object' &&
  window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ?   
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({
      // Specify extension’s options like name, actionsBlacklist, actionsCreators, serialize...
    }) : compose;

    const enhancer = composeEnhancers(
      applyMiddleware(sagaMiddleware),
      // other store enhancers if any
    );
export default function getStore(){

  const store = createStore(getRootReducer(),enhancer);
 // const persistor = persistStore(store);

  sagaMiddleware.run(rootSaga);

	return {store};
}
