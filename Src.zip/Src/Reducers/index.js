import { combineReducers } from 'redux';
import loginReducer from './loginReducer';


export default function getRootReducer() {
    return combineReducers({
        loginReducer : loginReducer
    });
}