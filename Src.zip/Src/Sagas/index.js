import * as types from '../Actions/actionTypes';
import { call, put, takeEvery, takeLatest } from 'redux-saga/effects';
import {fetchUserLogin} from './loginSaga'

export default function* rootSaga() {


    yield takeEvery(types.LOGIN_FETCH_REQUESTED,fetchUserLogin)

} 