import React, { Component } from 'react';
import { View, Text ,Button } from 'react-native';
import style from '../Config/StyleSheet/Style';
import * as loginActions  from '../Actions/loginActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
   
    return (
      <View style={style.containerStyle}>
          <Text>{String(this.props.login.isLoading)}</Text>
        <Button title = "Login" onPress ={()=> this.props.loginActions.loginFetchRequested('admin@mycms.com','devang_9978')} />
      </View>
    );
  }
}

//post
const mapDispatchToProps = (dispatch) => {
    return {
        loginActions: bindActionCreators(loginActions, dispatch)
    }
};

//get
const mapStateToProps = (state) => {
    return {
      login : state.loginReducer,
    }
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
