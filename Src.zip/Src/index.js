import React, { Component } from 'react';
import { View, Text } from 'react-native';
import Home from './Screens/Home';
import getStore from './store';
import { Provider } from 'react-redux';

const { store } = getStore(); 

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  render() {
    return (
     <Provider store={store}>
        <Home />
     </Provider>
    );
  }
}
