import * as types from './actionTypes';


export function itemIsLoading(bool) {
    return {
      type: types.LOGIN_IS_LOADING,
      isLoading: bool,
    }
  }
  
  export function itemsHasErrored(bool, msg) {
    return {
      type: types.LOGIN_HAS_ERRORED,
      hasErrored: bool,
      errorMsg: msg,
    }
  }
   
  
  export function itemsFetchDataSuccess(items) {
   
      return {
        type: types.LOGIN_FETCH_DATA_SUCCESS,
        items,
      }
    
  }

  
  export function loginFetchRequested(username, password) {
    return {
      type: types.LOGIN_FETCH_REQUESTED,
      payload: {username, password},
    }
  }
  