export const LOGIN_IS_LOADING = 'login_fetch_data';
export const LOGIN_FETCH_DATA_SUCCESS = 'login_fetch_data_success';
export const LOGIN_HAS_ERRORED = 'login_fetch_data_fail';

// Saga Actions types

export const LOGIN_FETCH_REQUESTED = 'LOGIN_FETCH_REQUESTED';

