
import Global from '../Config/Global/global';

import axios from 'axios';

const apiURL = Global.apiUrl;

var api = {

  postlogin(username,password) {

    return fetch('https://facebook.github.io/react-native/movies.json')
    .then((response) => response.json())
    .then((responseJson) => {
      return responseJson.movies;
    })
    .catch((error) => {
      console.error(error);
    });
}

    // var reqData = `grant_type=password&username=${username}&password=${password}`;

    // console.log(reqData);
    // axios({
    //     method: 'post',
    //     url: 'https://pte.examgroup.org/TOKEN',
    //         data: (reqData),   
    
    //     headers: { 
    //       "Content-Type": "application/x-www-form-urlencoded",
    //     }
    //   }).then((response) =>{
    
    //      console.log(response);

    //      return response;
    
           
    //     }).catch((error) =>{

    //       console.log(error);
         
    
    //      }).finally(()=>{

    //       console.log("finally Called");
    
    //      })
   
    //     }

    
}

export default api;